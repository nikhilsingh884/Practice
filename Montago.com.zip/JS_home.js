
// ----------------hamburger-menu-slidetoggle-----------------------

$(document).ready(function () {
    $('.hamburger').click(function () {
        $('.onclick-menu').slideToggle(200);
    });
});




