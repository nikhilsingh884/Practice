// ----------------hamburger-menu-slidetoggle-----------------------


$(document).ready(function () {
    $('.offices').hover(function () {
        $('.office-list').slideDown(150);
    }, function () {
        $('.office-list').slideUp(150);
    });

    $('.hamburger-icon').click(function () {
        $('.ham-menu').slideToggle(175);
        $(".hamburger-icon").toggleClass("ham-bg");
    });


});


