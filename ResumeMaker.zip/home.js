

// -----------------------------------------------------------

function save() {
    var name = document.getElementById("name").value;
    document.getElementById("hname").innerHTML = name;
    document.getElementById("name").value = "";

    var designation = document.getElementById("designation").value;
    document.getElementById("hdesignation").innerHTML = designation;
    document.getElementById("designation").value = "";


    var professional = document.getElementById("professional").value;
    document.getElementById("hprofessional").innerHTML = professional;
    document.getElementById("professional").value = "";


    var address = document.getElementById("address").value;
    document.getElementById("haddress").innerHTML = address;
    document.getElementById("address").value = "";



    var phone = document.getElementById("phone").value;
    document.getElementById("hphone").innerHTML = phone;
    document.getElementById("phone").value = "";



    var email = document.getElementById("email").value;
    document.getElementById("hemail").innerHTML = email;
    document.getElementById("email").value = "";


    var about = document.getElementById("about").value;
    document.getElementById("habout").innerHTML = about;
    document.getElementById("about").value = "";


}

// -------------------------------------------------------------------------------


function addLanguages() {
    const languagesInput = document.getElementById("languages");
    const language = languagesInput.value;
    const languageList = document.getElementById("hlanguages");

    const newListItem = `<li>${language}</li>`;
    languageList.insertAdjacentHTML("afterbegin", newListItem);
    languagesInput.value = "";
}

// -------------------------------------------------------------------------------

function addExperience() {
    const experienceInput = document.getElementById("experience");
    const experience = experienceInput.value;
    const experienceList = document.getElementById("hexperience");

    const newListItem = `<li>${experience}</li>`;
    experienceList.insertAdjacentHTML("afterbegin", newListItem);
    experienceInput.value = "";
}

// -------------------------------------------------------------------------------

function addSkills() {
    const skillsInput = document.getElementById("skills");
    const skills = skillsInput.value;
    const skillsList = document.getElementById("hskills");

    const newListItem = `<li>${skills}</li>`;
    skillsList.insertAdjacentHTML("afterbegin", newListItem);
    skillsInput.value = "";
}

// -------------------------------------------------------------------------------

function addHobbies() {
    const hobbiesInput = document.getElementById("hobbies");
    const hobbies = hobbiesInput.value;
    const hobbiesList = document.getElementById("hhobbies");

    const newListItem = `<li>${hobbies}</li>`;
    hobbiesList.insertAdjacentHTML("afterbegin", newListItem);
    hobbiesInput.value = "";
}

// -------------------------------------------------------------------------------

function addCertifications() {
    const certificationsInput = document.getElementById("certifications");
    const certifications = certificationsInput.value;
    const certificationsList = document.getElementById("hcertifications");

    const newListItem = `<li>${certifications}</li>`;
    certificationsList.insertAdjacentHTML("afterbegin", newListItem);
    certificationsInput.value = "";
}

// -------------------------------------------------------------------------------

function addEducation() {
    const educationInput = document.getElementById("education");
    const education = educationInput.value;
    const educationList = document.getElementById("heducation");

    const newListItem = `<li>${education}</li>`;
    educationList.insertAdjacentHTML("afterbegin", newListItem);
    educationInput.value = "";
}


// -------------------------------------------------------------------------------

function addWebsite() {
    const websiteInput = document.getElementById("website");
    const website = websiteInput.value;
    const websiteList = document.getElementById("hwebsite");

    const newListItem = `<li>${website}</li>`;
    websiteList.insertAdjacentHTML("afterbegin", newListItem);
    websiteInput.value = "";
}

// -------------------------------------------------------------------------------

function applyColor() {
    let color = document.getElementById("color").value;
    document.getElementById("header").style.backgroundColor = color;

    // const myElement = document.querySelector('#head-before');

    // // Get the computed styles of the ::before pseudo-element
    // const beforeStyles = window.getComputedStyle(myElement, '::before');

    // // Update the background-color property of the ::before pseudo-element
    // myElement.style.setProperty('--before-background-color', color);

}

