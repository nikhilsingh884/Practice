
// ----------------hamburger-menu-slidetoggle-----------------------

$(document).ready(function () {
    $('.hamburger').click(function () {
        $('.onclick-menu').slideToggle(250);
        $(".hamburger").toggleClass("ham-bg");
        $("#hamburger").toggleClass("hamburger-rotate")
    });
});

// ----------------mobile-validation-----------------------
function mnovalid() {
    let mno = document.getElementById("mno").value;
    let regex = /^[0-9]*$/
    if (regex.test(mno)) {
        document.getElementById("msg").innerHTML = ""
    }
    else {
        document.getElementById("msg").innerHTML = "Enter valid mobile no.";

    }
}

// -----------------email-validation-----------------------
function emailvalid() {
    let email = document.getElementById("email").value;
    let regex = /^[0-9]*$/;
    if (regex.test(email)) {
        document.getElementById("msg-2").innerHTML = "";
    }
    else {
        document.getElementById("msg-2").innerHTML = "Enter valid email-ID";
    }
}


// -----------------full blank-validation-----------------------

function checkBlank() {
    let mno = document.getElementById("mno").value;
    let email = document.getElementById("email").value;
    if (mno == "" &
        email == "") {
        document.getElementById("msg-3").innerHTML = "Enter details";

        return false;
    }

}

AOS.init();





