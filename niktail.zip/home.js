$(document).ready(function () {
    $('.toggle').click(function () {
      $(".ham-menu").slideToggle(200);
    })
  })